const ServierURL = 'https://www.iqhyun.com/app/';

const serverAdress = {
  'titlepage':ServierURL+'content.json',
  'fenleikecheng':ServierURL+'fenleititle.json',
  'videokecheng':ServierURL+'video.json',
  'mainPages':ServierURL+'./index.php?i=2&c=entry&eid=36',
  'testmodel':'https://www.iqhyun.com/app/index.php?i=2&c=utility&a=visit&do=showjs&m=ck_zhxt',
};