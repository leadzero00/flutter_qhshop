import 'package:flutter/material.dart';

class KechengPage extends StatefulWidget {
  @override
  _KechengPageState createState() => _KechengPageState();
}

class _KechengPageState extends State<KechengPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Center(
        child: Text('我是面授课程'),
      ),
    );
  }
}