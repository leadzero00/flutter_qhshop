import 'package:flutter/material.dart';

class KaoshiPage extends StatefulWidget {
  @override
  _KaoshiPageState createState() => _KaoshiPageState();
}

class _KaoshiPageState extends State<KaoshiPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Center(
        child: Text('我是在线考试'),
      ),
    );
  }
}